import React, {Component} from 'react';

class Home extends Component{
    render(){
        return(
            <div>
                <h2>HOME</h2>
                <p>home</p>
            </div>
        );
    }
}

export default Home;