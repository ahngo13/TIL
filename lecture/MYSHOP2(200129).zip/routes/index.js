const express = require('express');
const router = express.Router();

router.get('/', (req,res)=>{
    let logind=0;
    if(req.session.email){
        logind=1;
    }else{
    }
    res.render('index', {title:"MySHOP2", logind:logind, name:req.session.name});
});

module.exports = router;