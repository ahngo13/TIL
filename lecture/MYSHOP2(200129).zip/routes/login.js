const express = require('express');
const router = express.Router();
// const members = require('./members');
const con = require('./mysql');

router.post('/', (req,res)=>{
    let message;

    const sql = `SELECT * FROM members where email='${req.body.email}'`;
    con.query(sql, function (err, result, fields) {
        if (err) {
            console.log(err);
        }else{
            // console.log(result.length);
            console.log(result.length);
            if(result.length > 0){
                req.session.email = req.body.email;  
                req.session.name = result[0].name;         
                message = "login ok";
                console.log(message);
            }else{
                message = "login Fail";
                console.log(message);

            }
            res.json({message:message});
        }
    });
});

module.exports = router;