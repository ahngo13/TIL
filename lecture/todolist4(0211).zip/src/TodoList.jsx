import React, {Component} from 'react';
import TodoItem from './TodoItem';
import "./css/TodoList.css";
import $ from 'jquery';

class TodoList extends Component{
    componentWillMount(){
        //render 전 서버 접속
        $.get('http://localhost:8080/',(returnData)=>{
            console.log(returnData.message);
        });
        
    }

    state={
        items:[]
    }

    deleteItem=(key)=>{
        const send_param = {
            key
        };

        $.post('http://localhost:8080/item/delete', send_param, (returnData)=>{
            if(returnData.message){
                const filteredItems = this.state.items.filter((item)=>{
                    return key !== item.key;
                });
                
                this.setState({
                    items : filteredItems
                });

            }else{
                alert('일정 삭제 오류');
            }
        });
        
    }

    addItem=()=>{
        /* this.state.items.unshift({
            text: this._inputE.value,
            key:Date.now()
        }); */

        const send_param = {
            text: this._inputE.value,
            key:Date.now()
        };

        $.post('http://localhost:8080/item/add', send_param, (returnData)=>{
            if(returnData.message){
                this.state.items.unshift(send_param);
                this.setState({
                    items: this.state.items
                });
            }else{
                alert('일정 추가 오류');
            }

            this._inputE.value='';
            this._inputE.focus();
        });

    }
    render(){
        return(<div className="todoListMain">
                <div className="header">
                    <input ref={ref=>this._inputE=ref}></input>
                    <button onClick={this.addItem}>add</button>
                    <TodoItem items={this.state.items} superDelete={this.deleteItem}/>
                </div>
            </div>);
    }
}

export default TodoList;