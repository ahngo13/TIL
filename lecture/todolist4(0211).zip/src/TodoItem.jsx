import React, {Component} from 'react';

class TodoItem extends Component{
    /* delete=(key)=>{
        this.props.superDelete(key);
    } */

    render(){
        const myItems = this.props.items.map((item)=>{
        return <li key={item.key} onClick={this.props.superDelete.bind(null,item.key)}>{item.text}</li>
        });
        return(
        <ul>{myItems}</ul>
        );
    }
}

export default TodoItem;