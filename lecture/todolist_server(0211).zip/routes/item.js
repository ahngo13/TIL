const mysql = require("mysql");
const express = require("express");
const router = express.Router();

const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "mysql",
  database: "nodejs",
  port: "3307"
});

router.post("/delete", (req, res) => {
  const sql = `DELETE FROM todolist WHERE \`key\` = '${req.body.key}'`;
  console.log(sql);
  con.query(sql, function(err, result) {
    if (err) {
      res.json({ message: false });
    } else {
      res.json({ message: true });
    }
  });
});

router.post("/add", (req, res) => {
  const key = parseInt(req.body.key);
  console.log(key);
  const sql = `INSERT INTO todolist (\`key\`, text) VALUES (${key}, '${req.body.text}')`;
  console.log(sql);
  con.query(sql, function(err, result) {
    if (err) {
      console.log(err);
      res.json({ message: false });
    } else {
      console.log("1 record inserted");
      res.json({ message: true });
    }
  });
});

module.exports = router;
