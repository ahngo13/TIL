const express = require("express");
const router = express.Router();
const Comment = require("../schemas/comment");
const User = require("../schemas/user");
const mongo = require("mongodb");

router.post("/delete", async (req, res) => {
  try {
    const result = await Comment.remove({
      _id: req.body._id
    });
    res.json({ message: "댓글이 삭제되었습니다." });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/update", async (req, res) => {
  try {
    const result = await Comment.update({
      _id: req.body._id,
      name: req.body.name,
      age: req.body.age,
      married: req.body.married
    });
    res.json({ message: "댓글이 수정 되었습니다." });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/add", async (req, res) => {
  try {
    const comment = new Comment(req.body);
    const result = await comment.save();
    res.json({ message: "댓글이 달렸습니다" });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/getAllComment", async (req, res) => {
  try {
    console.log("---------------------");
    console.log(req.body);
    const comments = await Comment.find({ commenter: req.body.id }).populate(
      "commenter"
    );
    // const user = await User.findOne({ _id: mongo.ObjectID(req.body._id) });
    console.log(comments);
    res.json({ message: comments });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

module.exports = router;
