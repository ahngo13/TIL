const express = require("express");
const router = express.Router();
const mongo = require("mongodb");

//mongodb 연동
const MongoClient = mongo.MongoClient;
const url = "mongodb://localhost:27017/nodejs";
let dbo;
MongoClient.connect(url, function(err, db) {
  if (err) {
    console.log(err);
  } else {
    dbo = db.db("nodejs");
  }
});

router.post("/getAllMember", (req, res) => {
  dbo
    .collection("member")
    .find({})
    .toArray(function(err, result) {
      if (err) {
        console.log(err);
        res.json({ message: false });
      } else {
        res.json({ message: result });
      }
    });
});

router.post("/add", (req, res) => {
  dbo.collection("member").insertOne(req.body, function(err, result) {
    if (err) {
      console.log(err);
      res.json({ message: false });
    } else {
      console.log("1 document inserted");
      res.json({ message: true });
    }
  });
});

router.post("/update", (req, res) => {
  console.log(req.body._id);
  const myquery = { _id: mongo.ObjectID(req.body._id) };
  console.log(myquery);
  const newvalues = {
    $set: { name: req.body.name, age: req.body.age, married: req.body.married }
  };
  dbo.collection("member").updateOne(myquery, newvalues, function(err, result) {
    if (err) {
      console.log(err);
      res.json({ message: false });
    } else {
      console.log("1 document updated");
      res.json({ message: true });
    }
  });
});

router.post("/delete", (req, res) => {
  const myquery = { _id: mongo.ObjectID(req.body._id) };
  console.log(req.body._id);
  dbo.collection("member").deleteOne(myquery, function(err, result) {
    if (err) {
      console.log(err);
      res.json({ message: false });
    } else {
      console.log("1 document delete");
      res.json({ message: true });
    }
  });
});

module.exports = router;
