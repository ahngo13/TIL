const Post = require("../models").Post;
const User = require("../models").User;

async function getAllPosts() {
  try {
    const posts = await Post.findAll({
      include: {
        model: User,
        attributes: ["id", "nick"]
      },
      order: [["createdAt", "DESC"]]
    });
    return posts;
  } catch (err) {
    console.log(err);
    return null;
  }
}

module.exports = getAllPosts;
