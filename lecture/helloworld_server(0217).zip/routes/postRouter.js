const express = require("express");
const router = express.Router();
const Post = require("../models").Post;
// const Follow = require("../models").Follow;
const User = require("../models").User;
const Hashtag = require("../models").Hashtag;

router.post("/follow", async (req, res) => {
  try {
    const folowerId = req.body.login_id;
    const folowingId = req.body.post_id;
    console.log(folowerId);
    console.log(folowingId);

    try{
        
    const user = await User.findOne({where:{nick:req.body.user}})
    // const following = await User.findOne({where:{nick:req.body.following}})

    await user.addFollowing(following);

    res.json({ message: `팔로우 되었습니다!` });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/getAllPosts", async (req, res) => {
  try {
    const posts = await Post.findAll({
      include: {
        model: User,
        attributes: ["id", "nick"]
      },
      order: [["createdAt", "DESC"]]
    });
    res.json({ posts });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/upload", async (req, res, next) => {
  const content = req.body.content;
  const userId = req.body.id;
  const img = req.body.img;

  try {
    if (userId != null && userId != undefined) {
      const post_result = await Post.create({
        content,
        userId,
        img
      });
      // #으로 되어있는 문자중에서 띄어쓰기 한 문자를 제외하고
      const hashtags = content.match(/#[^\s#]*/g);
      console.log(hashtags);
      if (hashtags) {
        //
        //다 돌 때까지 기다림
        const hashtag_result = await Promise.all(
          hashtags.map(tag => {
            // 중복되지 않는 것만 insert
            Hashtag.findOrCreate({
              where: { title: tag.slice(1).toLowerCase() }
            });
          })
        );
        await post_result.addHashtags(
          hashtag_result.map(r => {
            return r[0];
          })
        );
      }

      // const posts = getAllPosts();
      res.json({ message: true });
    }
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

module.exports = router;
