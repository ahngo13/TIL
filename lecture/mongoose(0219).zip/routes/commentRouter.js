const express = require("express");
const router = express.Router();
const Comment = require("../schemas/comment");

router.post("/delete", async (req, res) => {
  try {
    await Comment.remove({
      _id: req.body._id
    });
    res.json({ message: "댓글이 삭제되었습니다." });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/update", async (req, res) => {
  try {
    await Comment.updateOne({
      _id: req.body._id},{
      commenter: req.body.commenter,
      comment: req.body.comment,
    });
    res.json({ message: "댓글이 수정 되었습니다." });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/add", async (req, res) => {
  try {
    const comment = new Comment(req.body);
    await comment.save();
    res.json({ message: "댓글이 달렸습니다" });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/getAllComment", async (req, res) => {
  try {
    console.log("---------------------");
    console.log(req.body);
    const comments = await Comment.find({}).populate(
      "commenter"
    );
    // const user = await User.findOne({ _id: mongo.ObjectID(req.body._id) });
    console.log(comments);
    res.json({ message: comments });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

module.exports = router;
