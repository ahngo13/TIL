const mysql = require("mysql");
const express = require("express");
const router = express.Router();
const User = require("../models").User;

const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "mysql",
  database: "nodejs",
  port: "3307"
});

router.post("/insert", async (req, res, next) => {
  const nick = req.body.name;
  const email = req.body.email;
  const password = req.body.pw;
  const comments = req.body.comments;
  console.log("---------------------------");
  try {
    const result = await User.create({
      email,
      nick,
      password
    });
    console.log(result);
    res.json({ message: `가입완료 되었습니다!`, name: nick });
  } catch (err) {
    console.log(err);
    res.json({ message: false });
  }
});

router.post("/login", (req, res) => {
  console.log(req.body);
  const email = req.body.email;
  const pw = req.body.pw;
  const sql = `SELECT * FROM members WHERE email= ? and pw= ?`;
  //취약한 문자열이 들어와도 sql 문장이 고장되므로 안전
  con.query(sql, [email, pw], function(err, result) {
    if (err) {
      res.json({ message: false });
    } else {
      console.log("/login" + req.sessionID);
      if (result[0]) {
        req.session.email = result[0].email;
        res.json({ message: result[0].name });
      } else {
        res.json({ message: `없는 회원입니다.` });
      }
    }
  });
});

/* router.post("/insert", (req, res) => {
  console.log(req.body);
  const name = req.body.name;
  const email = req.body.email;
  const pw = req.body.pw;
  const comments = req.body.comments;
  const sql = `INSERT INTO members (name, email, pw, comments) VALUES (?, ?, ?, ?)`;
  //취약한 문자열이 들어와도 sql 문장이 고장되므로 안전
  con.query(sql, [name, email, pw, comments], function(err, result) {
    if (err) {
      res.json({ message: false });
    } else {
      res.json({ message: `가입완료 되었습니다!`, name: name });
    }
  });
}); */

router.get("/logout", (req, res) => {
  console.log("/logout" + req.sessionID);
  req.session.destroy(() => {
    res.json({ message: true });
  });
});

module.exports = router;
