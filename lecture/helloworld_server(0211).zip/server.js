const express = require("express");
const app = express();
const cors = require("cors");
const memberRouter = require("./routes/memberRouter");

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/member", memberRouter);

//app.use(express.json());

app.get("/", (req, res) => {
  res.json({ ip: "111.222.333.444" });
});

app.listen(8080, () => {
  console.log("8080 server ready");
});
