$(document).ready(function(){
    let login_form = 'ID : <input id="id" class="form-control"><br>';
    login_form += 'PW : <input id="pw" type="password" class="form-control"><br>';
    login_form += '<button id="login_btn" class="btn btn-success">로그인</button>';
    $('#hello_div').click(function(){
        $('#content_div').html(login_form);
    });

    $(document).on('click','#login_btn',function(){
        const id = $('#id').val();
        const pw = $('#pw').val();
        const param = {
            sign:"login",id, pw
        };
        
        $.post('login', param, function(resultData){
            alert(resultData.message);
            if(resultData.resultCode){
                let logout_form = '<div id="logout_btn" class="btn btn-danger">logout</div>';
                logout_form += '<br><hr>쇼핑하기<br>';                
                logout_form += '<input type="radio" name="product" value="apple">사과</input>';
                logout_form += '<input type="radio" name="product" value="orange">오렌지</input>';
                logout_form += '<input type="radio" name="product" value="banana">바나나</input>';
                logout_form += '<br><div id="basket_view_div"></div>';
                //장바구니 넣기 추가
                logout_form += `<br><div id="basket_check_div">`;
                logout_form += `<input type="checkbox" name="youtube" value="구독">구독</input>`;
                logout_form += `<input type="checkbox" name="youtube" value="좋아요">좋아요</input>`;
                logout_form += `<input type="checkbox" name="youtube" value="알람 설정">알람 설정</input>`;
                logout_form += '<input type="button"  id="basket_btn" value="장바구니 넣기"><br>';
                logout_form += '<hr><input type="button"  id="basket_view_btn" value="장바구니 보기">';
                logout_form += '</div>';

                $('#content_div').html(logout_form);
            }else{
                $('#id').val('');
                $('#pw').val('');
            }
        });
    });

    $(document).on('click','#logout_btn',function(){
    	const param = {
            sign:"logout"
        };
        
        $.post('logout', param, function(result){
        	alert(result.message);
        	location.reload();
        });
        
//        $('#content_div').html(login_form);
    });
    
    $(document).on('click','#basket_btn',function(){
        const fruitRadio=$(':input:radio[name=product]:checked').val();
        //체크박스 항목 추가 checked된 객체들을 변수에 넣음
        const youtubeChk=$(':input:checkbox[name=youtube]:checked');
        //넘겨줄 배열 변수 선언
        const product = [];
        
        //라디오 버튼으로 목록을 선택했는지 판별하기 위한 변수
        let i=0;
        //라디오 버튼을 체크했을 경우
        if(fruitRadio != '' && fruitRadio != undefined){
            //배열의 첫번째 값에 넣어줌
            product[0]=fruitRadio;
            //변수 1로 변경
            i=1;
        }

        //체크된 목록들을 반복문으로 value값을 배열에 넣어줌
        for(y=0; y<youtubeChk.length;y++){
            //라디오 버튼 목록 선택 안할 시
            if(i==0){
                product[y] = youtubeChk[y].value;
            //라디오 버튼 목록 선택할 시
            }else{
                product[y+1] = youtubeChk[y].value;
            }
        }
        
        //ajax로 배열 데이터를 넘겨줄 때 세팅해줘야 함
        $.ajaxSettings.traditional = true;

        //파라미터 세팅
        const send_param={sign:"basket", product:product};
        $.post('basket',send_param,function(returnData){
            alert(returnData.message);
        });
    });
    
    $(document).on('click','#basket_view_btn',function(){      
        const send_param={sign:"basket_view"};
        $.post('basket_view', send_param,function(returnData){
           alert(returnData.message);
            
        });
    });
});