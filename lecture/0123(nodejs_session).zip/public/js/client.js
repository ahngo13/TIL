$(document).ready(function(){
    let login_form = `ID : <input id="id" class="form-control"><br>`;
    login_form += `PW : <input id="pw" class="form-control"><br>`;
    login_form += `<button id="login_btn" class="btn btn-success">로그인</button>`;
    $('#hello_div').click(function(){
        $('#content_div').html(login_form);
    });

    $(document).on('click','#login_btn',function(){
        const id = $('#id').val();
        const pw = $('#pw').val();
        const param = {
            id, pw,
        };
        
        $.post('login', param, function(resultData){
            alert(resultData.message);
            if(resultData.resultCode){
                let logout_form = `<div id="logout_btn" class="btn btn-danger">logout</div>`;
                $('#content_div').html(logout_form);
            }else{
                login_form +=`<br><br><img src="img/smile.jpeg">`;
                $('#content_div').html(login_form);
                $('#id').val('');
                $('#pw').val('');
            }
        });
    });

    $(document).on('click','#logout_btn',function(){
        alert('로그아웃 되셨습니다!');
        $('#content_div').html(login_form);
    });
});