import React, {Component} from 'react';
import axios from 'axios';
axios.defaults.withCredentials = true;
const headers={withCredentials:true};

class Contact extends Component{
    state={
        name:''
    }
    memberInsert=()=>{
        const send_param={
            headers,
            name: this.joinName.value,
            email : this.joinEmail.value,
            pw : this.joinPw.value,
            comments : this.joinComment.value
        }

        axios.post('http://localhost:8080/member/insert',send_param)
        //정상 수행
        .then((returnData)=>{
            if(returnData.data.message){
                this.setState({
                    name: returnData.data.name
                });
            }else{
                alert('회원가입 실패');
            }
        })
        //에러
        .catch((err)=>{
            console.log(err);
        });

    }
    render(){
        if(this.state.name){
            return(
                <div>
                    <h2>{this.state.name}님 회원가입 되셨습니다!</h2>
                </div>
            );
        }else{
            return(
                <div>
                    <h2>Contact</h2>
                    <p>회원가입</p>
                    이름 : <input ref={ref=>this.joinName=ref}/> <br/>
                    이메일 : <input ref={ref=>this.joinEmail=ref} /> <br/>
                    비밀번호 : <input ref={ref=>this.joinPw=ref} /> <br/>
                    comments : <input ref={ref=>this.joinComment=ref} /> <br/>
                    <input type="button" value="가입하기" onClick={this.memberInsert}/>
                </div>
            );
        }
    }
}

export default Contact;