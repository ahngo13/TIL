import React, {Component} from 'react';
import "./css/Menu.css";
import $ from 'jquery';
import { HashRouter, NavLink } from 'react-router-dom';
import {} from "jquery.cookie";
import axios from 'axios';
axios.defaults.withCredentials = true;
const headers={withCredentials:true};

class Menu extends Component{

    state={
        login_nick:"",
        loginStyle:"inline-block",
        logoutStyle:"none"
    }

    logout=()=>{
        axios.get('http://localhost:8080/member/logout',{
            headers
        }).then((returnData)=>{
            if(returnData.data.message){
                $.removeCookie("login_nick");
                $.removeCookie("login_id");
                this.setState({
                    login_nick: "",
                    loginStyle:"inline-block",
                    logoutStyle:"none"
                });
            }
        });
    }

    login=()=>{
        const send_param = {
            headers,
            email : this.emailE.value,
            pw : this.pwE.value
        };

        axios.post('http://localhost:8080/member/login',send_param)
        .then((returnData)=>{
            if(returnData.data.nick){
                $.cookie("login_nick",returnData.data.nick);
                $.cookie("login_id",returnData.data.id);
                this.setState({
                    login_nick:returnData.data.nick,
                    loginStyle:"none",
                    logoutStyle:"inline-block"
                });
            }else{
                alert("login fail");
            }
            
            this.emailE.value='';
            this.pwE.value='';
            this.emailE.focus();
        });
    }

    render(){
        const loginStyle={
            display:this.state.loginStyle
        }
        const logoutStyle={
            display:this.state.logoutStyle
        }

        let login_nick;

        if($.cookie("login_nick")){
            login_nick=$.cookie('login_nick');
            loginStyle.display = "none";
            logoutStyle.display = "inline-block";
        }

        let visibility = "hide";

        if(this.props.menuVisibility){
            visibility = "show";
        }

        return(
            <div id="flyoutMenu" onDrag={this.props.handleMouseDown} className={visibility}>
            <HashRouter>
                <button id="roundButton" onMouseDown={this.props.handleMouseDown}></button>
                <div style={loginStyle}>
                    이메일 : <input ref={ref=>this.emailE=ref}/><br/>
                    비밀번호 : <input type="password" ref={ref=>this.pwE=ref}/><br/>
                    <button onClick={this.login}>로그인</button>
                    <NavLink to='/Contact'>
                    <button onClick={this.props.handleMouseDown}>회원가입</button>
                    </NavLink>
                </div>
                <div style={logoutStyle}>
                    <div>{login_nick}님 환영합니다!</div>
                    <button onClick={this.logout}>로그아웃</button>
                </div>
                <h2><NavLink exact to="/">Home</NavLink></h2>
                <h2><a href="/">About</a></h2>
                <h2><NavLink to="/Contact">Contact</NavLink></h2>
                <h2><a href="/">Search</a></h2>
            </HashRouter>
        </div>
        );
    }
}

export default Menu;