import React, {Component} from 'react';
import axios from 'axios';
import $ from 'jquery';
import {} from 'jquery.cookie';

axios.defaults.withCredentials = true;
const headers = {withCredentials : true}

class Post extends Component{
    state={
        posts:[]
    }

    follow=(param)=>{
        console.log(param.id);
        const send_param={
            headers,
            login_id:$.cookie("login_id"),
            post_id:param.id
        }
        
        try{
            axios.post('http://localhost:8080/post/follow',send_param)
             //정상 수행
            .then((returnData)=>{
                if(returnData.data.message){
                    alert(returnData.data.message);
                }else{
                    alert('팔로우 실패');
                }
            })
            //에러
            .catch((err)=>{
                console.log(err);
            });
        }catch(err){
            console.log(err);
        }

        

    }

    uploadPost= async()=>{
        const send_param={
            headers,
            id:$.cookie("login_id"),
            content:this.postE.value,
            img:''
        }
        
        try{
            await axios.post('http://localhost:8080/post/upload',send_param);
            const result = await axios.post('http://localhost:8080/post/getAllPosts',{headers});
            // console.log(result.data.posts);
            // console.log(typeof(result.data.posts));
            if(result.data.posts){
                this.setState({
                    posts:result.data.posts
                });
            }
            console.log(result);
        }catch(err){
            console.log(err);
        }

    }

    render(){
        const postStyle={
            width:400,
            height:150,
            borderStyle:"solid",
            borderColor:"gray",
            margin:5
        }
        let posts = this.state.posts.map((post)=>{
            console.log(post);
            console.log(post.user);
            let nick = post.user.nick;
            let id = post.user.id;
            let follow = <button onClick={this.follow.bind(null,{id})}>팔로우 하기</button>;
            if($.cookie('login_nick')===post.user.nick){
                nick='';
                follow ='';
            }
        return <div key={Math.random()*500} style={postStyle}>{nick}<br/>{post.content}<br/>{follow}
         
        </div>
        });
        return(
            <div>
                <h2>SNS Post</h2>
                <div>
                    <textarea ref={ref=>this.postE=ref} rows="5" cols="30"></textarea><br/>
                    <button>사진 업로드</button>
                    <button onClick={this.uploadPost}>짹짹</button>
                </div>
                <div>
                    {posts}
                </div>
            </div>
        );
    }
}

export default Post;