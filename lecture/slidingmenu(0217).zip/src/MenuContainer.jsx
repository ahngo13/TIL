import React, {Component} from 'react';
import MenuButton from './MenuButton';
import Menu from './Menu';
import Home from './Home';
import Post from './Post';
import Contact from './Contact';
import {Route,NavLink,HashRouter} from 'react-router-dom';


class MenuContainer extends Component{
       state = {
            visible:false
        };

    handleMouseDown=(e)=>{
        this.toggleMenu();

        console.log("clicked");
        e.stopPropagation();
    }

    toggleMenu=()=>{
        this.setState({
            visible:!this.state.visible
        });
    }

    render(){
        return(
            <div>
                <MenuButton handleMouseDown={this.handleMouseDown}/>
                <Menu handleMouseDown={this.handleMouseDown} menuVisibility={this.state.visible}></Menu>
                <HashRouter>
                <div>
                    <h1>Simple SPA</h1>
                    <ul className="header">
                        <li><NavLink exact to='/'>Home</NavLink></li>
                        <li><NavLink to='/post'>Post</NavLink></li>
                        <li><NavLink to='/contact'>Contact</NavLink></li>
                    </ul>
                    <div className="content">
                        <Route exact path="/" component={Home}/>
                        <Route path="/post" component={Post}/>
                        <Route path="/contact" component={Contact}/>
                    </div>
                </div>
                </HashRouter>
            </div>
        );
    }
}

export default MenuContainer;